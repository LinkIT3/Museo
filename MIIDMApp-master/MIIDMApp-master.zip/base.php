<?php
    $EMAIL_PER_BUG = "peppesteduto@gmail.com";
    $DB_USER = "root";
    $DB_PASSWORD = "";
    $DB_NAME = "museo";
    $DB_SERVER = "localhost";
?>
